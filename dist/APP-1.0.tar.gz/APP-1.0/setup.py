from distutils.core import setup

setup(name='APP',
      version='1.0',
      py_modules=['mail', 'main', 'map', 'noti', 'search', 'telegram', 'teller']
      )
